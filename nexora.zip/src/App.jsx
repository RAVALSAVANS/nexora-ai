import Header from './components/Header'
import Hero from './components/Hero'
import Slider from './components/Slider'
import CTA from './components/CTA'
import Ecosystem from './components/Ecosystem'
import CaseStudies from './components/CaseStudies'
import Solutions from './components/Solutions'
import Platform from './components/Platform'
import Contact from './components/Contact'
import Footer from './components/Footer'
import ScrollTop from './components/ScrollTop'
import useLenis from "./hooks/useLenis";
import React, { useState } from "react";
import IntroAnimation from './IntroAnimation'

function App() {
  const [loading, setLoading] = useState(true);
  useLenis();
   return (
    <>
      {loading && (
        <IntroAnimation onComplete={() => setLoading(false)} />
      )}

      {!loading && (
        <>
          <Header />
          <Hero />
          <Slider />
          <Solutions />
          <Platform />
          <Ecosystem />
          <CTA />
          <CaseStudies />
          <Contact />
          <Footer />
          <ScrollTop />
        </>
      )}
    </>
  );
}

export default App